package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var toggle: Button
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var waitingForCommand = false
    private val worker = Executors.newSingleThreadExecutor()

    // Set this to your HTTPS backend URL after deploying server.js (see README).
    private val aiEndpoint = "https://YOUR_BACKEND_DOMAIN.example/chat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 10, 25)
        window.navigationBarColor = Color.rgb(3, 10, 25)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition isn't available on this device."
        }
    }

    private fun buildUi() {
        val bg = Color.rgb(3, 10, 25)
        val cyan = Color.rgb(65, 220, 255)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 42, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = .18f
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI • VOICE INTERFACE"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 26)
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 88f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        status = TextView(this).apply {
            text = "Tap START, then say “Hey Jarvis”"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }
        transcript = TextView(this).apply {
            text = "Ready for your command."
            textSize = 15f
            setTextColor(Color.rgb(190, 220, 235))
            setPadding(16, 16, 16, 16)
        }
        val panel = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(8, 24, 42))
            addView(transcript)
        }
        toggle = Button(this).apply {
            text = "START LISTENING"
            setTextColor(Color.BLACK)
            setBackgroundColor(cyan)
            setOnClickListener {
                if (listening) stopListening() else {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
                    } else startListening()
                }
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(orb)
        layout.addView(status)
        layout.addView(panel, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 })
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition unavailable", Toast.LENGTH_LONG).show()
            return
        }
        listening = true
        waitingForCommand = false
        toggle.text = "STOP LISTENING"
        status.text = "Listening for “Hey Jarvis”…"
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { }
                override fun onBeginningOfSpeech() { status.text = if (waitingForCommand) "Listening for your command…" else "Listening for wake phrase…" }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { }
                override fun onError(error: Int) {
                    if (listening) status.postDelayed({ listenOnce() }, 650)
                }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim().orEmpty()
                    if (heard.isNotBlank()) handleSpeech(heard)
                    if (listening && !waitingForCommand) status.postDelayed({ listenOnce() }, 400)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) transcript.text = "Heard: $partial"
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            try { sr.startListening(intent) } catch (_: Exception) { if (listening) status.postDelayed({ listenOnce() }, 1000) }
        }
    }

    private fun handleSpeech(text: String) {
        transcript.text = "You: $text"
        val normalized = text.lowercase(Locale.ROOT)
        if (!waitingForCommand) {
            if (normalized.contains("hey jarvis") || normalized.contains("hey, jarvis") || normalized == "jarvis") {
                waitingForCommand = true
                status.text = "Wake phrase detected. Say your command."
                speak("Yes? How can I help?")
                // Speech recognizer is not a true always-on hotword engine. Restart after spoken prompt.
                status.postDelayed({ listenOnce() }, 900)
            }
            return
        }
        waitingForCommand = false
        if (normalized.contains("stop listening")) {
            stopListening()
            speak("Listening stopped.")
            return
        }
        when {
            normalized.contains("what time") || normalized == "time" -> {
                val answer = "The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                transcript.text = "You: $text\n\nJARVIS: $answer"
                speak(answer)
            }
            normalized.contains("open youtube") -> openApp("com.google.android.youtube", "YouTube")
            normalized.contains("open settings") -> {
                try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
                catch (_: Exception) { speak("I couldn't open settings.") }
            }
            else -> askAi(text)
        }
        if (listening) status.postDelayed({ listenOnce() }, 1000)
    }

    private fun openApp(packageName: String, label: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
            speak("Opening $label.")
        } else speak("$label is not installed.")
    }

    private fun askAi(prompt: String) {
        status.text = "Thinking…"
        if (aiEndpoint.contains("YOUR_BACKEND_DOMAIN")) {
            val msg = "AI backend isn't configured yet. Follow README to connect your private AI server."
            transcript.text = "You: $prompt\n\nJARVIS: $msg"
            speak("Please configure the AI server first.")
            return
        }
        worker.execute {
            try {
                val conn = (URL(aiEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(JSONObject().put("message", prompt).toString().toByteArray(Charsets.UTF_8)) }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                val answer = JSONObject(body).optString("reply", "Sorry, I couldn't get a reply.")
                runOnUiThread {
                    transcript.text = "You: $prompt\n\nJARVIS: $answer"
                    status.text = "Ready"
                    speak(answer)
                }
                conn.disconnect()
            } catch (_: Exception) {
                runOnUiThread {
                    status.text = "Connection error"
                    transcript.text = "Couldn't reach the AI server. Check your internet and backend URL."
                    speak("I can't connect to the AI server right now.")
                }
            }
        }
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun stopListening() {
        listening = false
        waitingForCommand = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        toggle.text = "START LISTENING"
        status.text = "Listening paused."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else status.text = "Microphone permission is required for voice commands."
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
