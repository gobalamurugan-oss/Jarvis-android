import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "20kb" }));

// Keep the API key on the server, never inside the Android APK.
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.get("/", (_req, res) => res.json({ status: "JARVIS backend online" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message ?? "").slice(0, 4000);
    if (!message.trim()) return res.status(400).json({ error: "message required" });

    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are JARVIS, a helpful, concise voice assistant. Reply naturally. The user may speak Tamil or English; respond in the language they use. Never claim you performed phone actions unless the app actually did so." },
        { role: "user", content: message }
      ],
      max_tokens: 350
    });
    res.json({ reply: response.choices[0]?.message?.content || "I don't have an answer yet." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(500).json({ error: "AI request failed" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JARVIS backend listening on ${port}`));
